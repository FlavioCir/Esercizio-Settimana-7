var nome;
var cognome;
var date;
var addBtn;
var elencoHTML;
var errore;
var erroreElenco;
var elenco = [];
var sovrascrivi;

window.addEventListener('DOMContentLoaded', init);

function init() {
	nome = document.getElementById('nome');
	cognome = document.getElementById('cognome');
	date = document.getElementById('date');
	addBtn = document.getElementById('scrivi');
	elencoHTML = document.getElementById('elenco');
	errore = document.getElementById('errore');
	erroreElenco = document.getElementById('erroreElenco');
	printData();
	eventHandler();
}

function eventHandler() {
	addBtn.addEventListener('click', function () {
		if (sovrascrivi) {
			overwrite(sovrascrivi);
		} else {
			controlla();
		}
	});
}

function printData() {
	fetch('http://localhost:3000/elenco')
		.then((response) => {
			return response.json();
		})
		.then((data) => {
			elenco = data;
			if (elenco.length > 0) {
				errore.innerHTML = '';
				elencoHTML.innerHTML = '';
				elenco.map(function (element) {
					let colonna1 = `<td><button type="button" class="btn me-2 btn-outline-danger" onClick="elimina(${element.id})"><i class="bi bi-trash3-fill"></i></button></td>`;
					let colonna2 = `<td><button type="button" class="btn btn-outline-success ms-1 me-2" onClick="modifica(${element.id})"><i class="bi bi-pencil-fill"></i></button></td>`;
					let colonna3 = `<td>${element.nome}</td>`;
					let colonna4 = `<td>${element.cognome}</td>`;
					let colonna5 = `<td>${element.date}</td>`;
					elencoHTML.innerHTML += `<tr>${colonna1}${colonna2}${colonna3}${colonna4}${colonna5}</tr>`;
				});
			} else {
				erroreElenco.innerHTML = 'Nessun elemento presente in elenco';
			}
		});
}

async function elimina(i) {
	richiesta = window.confirm('Sei sicuro di voler cancellare? Questa azione è irreversibile!');
	if (richiesta) {
		return fetch('http://localhost:3000/elenco/' + i, {
			method: 'DELETE'
		});
	}
}

function controlla() {
	if (nome.value != '' && cognome.value != '') {
		var data = {
			nome: nome.value,
			cognome: cognome.value,
			date: date.value,
		};
		addData(data);
	} else {
		errore.innerHTML = 'Compilare correttamente i campi!';
		return;
	}
}

async function addData(data) {
	let response = await fetch('http://localhost:3000/elenco', {
		method: 'POST',
		headers: {
			'Content-Type': 'application/json;charset=utf-8',
		},
		body: JSON.stringify(data),
	});
	clearForm();
}

function clearForm() {
	nome.value = '';
	cognome.value = '';
	date.value = '';
}

//------------------------------------------------------------

function modifica(i) {
	fetch('http://localhost:3000/elenco/' + i)
	.then((response) => {
		return response.json();
	})
	.then((data) => {
		nome.value = data.nome;
		cognome.value = data.cognome;
		date.value = data.date;
	});
	
	return sovrascrivi = i;
}

function overwrite(i) {
	if (nome.value && cognome.value) {
	fetch('http://localhost:3000/elenco/' + i, {
		method: 'PUT',
		headers: {
			'Content-Type': 'application/json;charset=utf-8',
		},
		body: JSON.stringify({
			"nome": nome.value,
			"cognome": cognome.value,
			"date": date.value
		}),
	});
	clearForm();
	} else {
		errore.innerHTML = 'Compilare correttamente i campi!';
		return;
	}
}